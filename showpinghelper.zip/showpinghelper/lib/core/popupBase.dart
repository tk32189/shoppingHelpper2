import 'package:showpinghelper/datatable/resultDataDTO.dart';

class popupBase
{
  ResultData resultdata = new ResultData();

}